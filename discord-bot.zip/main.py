import discord
import os
import random
from replit import db
from keep_alive import keep_alive

mouse_trigger = [
    'squeak', 'squeaky', 'squeek', 'squeeky', 'cheese', 'chese', 'chees',
    'cheesy', 'cheesey', 'chese', 'chesey'
]

mouse_reply = [
  '''
  …ᘛ⁐̤ᕐᐷ
  ''',
  '''
  ʕ￫ᴥ￩ʔ
  ''',
  '''
  <:3)~	
  ''',
  '''
  ୧ʕ•̀v•́ʔ୨
  ''',
  '''
  ʕ•́v•̀ʔっ
  '''
]

cat_trigger = [
    'meow', 'mrow', 'mow', 'mos', 'mouse', 'mousey', 'mousie', 'fish', 'fishy',
    'fishey'
]

cat_reply = [
    '''
──────▄▀▄─────▄▀▄
─────▄█░░▀▀▀▀▀░░█▄
─▄▄──█░░░░░░░░░░░█──▄▄
█▄▄█─█░░▀░░┬░░▀░░█─█▄▄█
  ''', 
  '''
  ฅ^•ﻌ•^ฅ
  ''', 
  '''     
       /\\\_\_/\\
  =( o      o  )=
       /       \\
    /\_|\_|\_(\_-|====,
  '''
  ,
  '''     
　　　　🌸＞\_\_\_\_フ
　　　　　| 　\_    \_  |
　 　　　／` ミ＿xノ
　　 　 /　　　 　 |
　　　 /　 ヽ　　 ﾉ
　 　 │　　|　|　|
　／￣|　  |　|　|
　| (￣ヽ＿_ヽ_)__)
　＼二つ🌷🍰🍓
  ''',
  '''
(=♡ ᆺ ♡=)
  ''',
  '''
  /\\\_\_/\\
( =•.•= )
(U      U)
  ''',
  '''
   /\\\__/\\
 ꒰ ˶• ༝ •˶ ꒱ ~♡︎
   / v v \\
   |         |
   づ\_\_づ
  '''
]

client = discord.Client()


@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))


@client.event
async def on_message(message):
    if message.author == client.user:
        return

    #I LOVE CHEES  
    msg = message.content.lower()

    if any(word in msg for word in cat_trigger):
        for word in msg.split():
            if word in cat_trigger:
                if 'y' in word:
                  word = word.replace('y', '')
                cat = random.choice(cat_reply)
                await message.channel.send(word.upper() + '?!' + cat)

    if any(word in msg for word in mouse_trigger):
        for word in msg.split():
            if word in mouse_trigger:
                if 'y' in word:
                  word = word.replace('y', '')
                mouse = random.choice(mouse_reply)
                await message.channel.send(word.upper() + '?!' + mouse)


my_secret = os.environ['TOKEN']

keep_alive()
client.run(my_secret)
